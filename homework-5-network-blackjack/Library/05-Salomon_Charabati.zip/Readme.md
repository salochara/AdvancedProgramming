# Blackjack with Sockets in C

Advanced Programming homework
Course at ITESM 
October '19

**To run the program**

`cd /path_to_directory/`

`make`

`./server {portnumber}`

`./client localhost {portnumber}`

**Example:**

`cd /Users/salo/Desktop/blackjack`

`make`

`./server 8989`

`./client localhost 8989`

The program should be running. You should now go to the client's terminal and start playing.

You should see this 

`=== CLIENT PROGRAM ===`

Then, type in your initial balance.

The game starts. You should see GAME READY!

Then, type in your bet for that hand and start playing! You shoukd type 's' to stay or 'h' to hit. 

The results will show up and yout balance will also be shown each hand.

Good luck!
