//
// Created by Salomón Charabati on 2019-10-06.
// Advanced Programming
// Homework #4 Vigenere Cypher
#include "vigenere.h"

int main()
{
    runProgram();

    return 0;
}
